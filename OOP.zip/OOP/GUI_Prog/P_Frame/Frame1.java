import java.awt.*;
class MyFrame{
public static void main(String ...args){
//create a frame
Frame f=new Frame("My First Frame");
//set the size of the frame
f.setSize(300,250);
//display the frame
f.setVisible(true);
}
}