import java.awt.*;
import java.awt.event.*;
class Dots extends Frame{
//to refresh the frame components
public void paint(Graphics g){
//set white color for dots
g.setColor(Color.red);
for(;;) //display dots forever
{
//generatex,y cordinates randomly,maximum 800 and 600 px
int x=(int) (Math.random()*800);
int y=(int) (Math.random()*600);
g.drawLine(x,y,x,y);
try
{
Thread.sleep(20);
}
catch(InterruptedException i){}
}
}
public static void main(String args[]){
Dots d= new Dots();
d.setSize(400,400);
d.setTitle("Randow Dots");
d.setVisible(true);

}
}
