import java.awt.*;
class MyFrame extends  Frame{
//call super class constructor to store title
MyFrame(String s){ super(s);}
public static void main(String ...args){
//create a frame
MyFrame f=new MyFrame("My First Frame");
//set the size of the frame
f.setSize(300,250);
//display the frame
f.setVisible(true);
}
}
