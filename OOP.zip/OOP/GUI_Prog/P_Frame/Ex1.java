import java.awt.*;
import java.awt.event.*;
class Ex1 extends Frame{
//to refresh the frame components
public void paint(Graphics g){
//set background color white ,this method is in Frame class
setBackground(Color.white);
//set the font for text
Font f=new Font("Arial",Font.BOLD+Font.ITALIC,30);
g.setFont(f);
g.setColor(Color.green);
g.drawString("First Apllication String",100,100);
}
public static void main(String args[]){
Ex1 d= new Ex1();
d.setSize(450,400);
d.setTitle("Randow Dots");
d.setVisible(true);
d.addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent e){
System.exit(0);
}
});

}
}
