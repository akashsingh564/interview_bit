//Choice demo
import java.awt.*;
import java.awt.event.*;
class MyChoice extends Frame implements ItemListener
{
//vars
String msg;
Choice ch;
MyChoice()
{
//set flow layout manager
this.setLayout(new FlowLayout());
//create new Choice 
ch=new Choice();
//add  some items  to choice menu
ch.add("English");
ch.add("Hindi");
ch.add("Telugu");
ch.add("sanskrit");
ch.add("French");
ch.add("German");
//add the choice menu to the frame
add(ch);
//add ItemListener to the choice menu
ch.addItemListener(this);

}//end of constructor

//this method is called when radio button is clicked
public void itemStateChanged(ItemEvent ie)
{
repaint(); //call paint() method
}
//display the selected radio label
public void paint(Graphics g)
{
g.drawString("selected Language",10,100);
msg=ch.getSelectedItem();
g.drawString(msg,10,130);
}
public static void main(String args[])
{
//create the frame
MyChoice mr=new MyChoice();
mr.setSize(400,400);
mr.setTitle("My Choice menu");
mr.setVisible(true);
//close the frame
mr.addWindowListener(new WindowAdapter()
{
public void windowClosing(WindowEvent we)
{
System.exit(0);
}
});
}
}

