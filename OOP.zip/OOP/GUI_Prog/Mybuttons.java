//push button
import java.awt.*;
import java.awt.event.*;
class Mybuttons extends Frame implements ActionListener
{

//mb button is called when a button is clicked
public void actionPerformed(ActionEvent ae)
{
//know the label of the button clicked by user
String str=ae.getActionCommand();
//change the bckgrnd color depending on the button clicked
if(str.equals("Yellow")) setBackground(Color.yellow);
if(str.equals("Blue")) setBackground(Color.blue);
if(str.equals("Pink")) setBackground(Color.pink);
}
public static void main(String args[])
{
//create the frame
Mybuttons mb=new Mybuttons();
mb.setSize(400,400);
mb.setTitle("My buttons");
mb.setVisible(true);
Button b1,b2,b3;
//do not set any layout
mb.setLayout(null);
//create push buttons
b1=new Button("Yellow");
b2=new Button("Blue");
b3=new Button("Pink");
//set the locations of buttons in the frame
b1.setBounds(100,100,70,40);
b2.setBounds(100,160,70,40);
b3.setBounds(100,220,70,40);
//add the buttons to the frame
mb.add(b1);
mb.add(b2);
mb.add(b3);
//add ActionListener to the buttons
b1.addActionListener(mb);
b2.addActionListener(mb);
b3.addActionListener(mb);
//close the frame
mb.addWindowListener(new WindowAdapter()
{
public void windowClosing(WindowEvent we)
{
System.exit(0);
}
});
}
}

