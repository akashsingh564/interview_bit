//Choice demo
import java.awt.*;
import java.awt.event.*;
class Mylist extends Frame implements ItemListener
{
//vars
int[] msg;
List lst;
Mylist()
{
//set flow layout manager
this.setLayout(new FlowLayout());
//create an empty list box that displays 4 items initially
//and multiple selection is also  enabled 
lst=new List(4,true);
//add  some items  to list box
lst.add("English");
lst.add("Hindi");
lst.add("Telugu");
lst.add("sanskrit");
lst.add("French");
lst.add("German");
//add the choice menu to the frame
add(lst);
//add ItemListener to the list box
lst.addItemListener(this);

}//end of constructor

//this method is called when radio button is clicked
public void itemStateChanged(ItemEvent ie)
{
repaint(); //call paint() method
}
//display the selected radio label
public void paint(Graphics g)
{
g.drawString("selected Language",100,200);
//get the selected item position numbers into msg[]
msg=lst.getSelectedIndexes();
//know each seelcted item's name  and display
for(int i=0;i<msg.length;i++)
{ 
String item =lst.getItem(msg[i]);
g.drawString(item,100,220+i*20);
}
}
public static void main(String args[])
{
//create the frame
Mylist mr=new Mylist();
mr.setSize(400,400);
mr.setTitle("My list box");
mr.setVisible(true);
//close the frame
mr.addWindowListener(new WindowAdapter()
{
public void windowClosing(WindowEvent we)
{
System.exit(0);
}
});
}
}

