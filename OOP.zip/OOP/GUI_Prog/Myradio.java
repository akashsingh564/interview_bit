//Radio Buttons demo
import java.awt.*;
import java.awt.event.*;
class Myradio extends Frame implements ItemListener
{
//vars
String msg="";
CheckboxGroup cbg;
Checkbox y,n;

Myradio()
{
//set flow layout manager
this.setLayout(new FlowLayout());

//create checkbox group object
cbg=new CheckboxGroup();

//create 2 radio buttons
y=new Checkbox("Yes",cbg,true);
n=new Checkbox("No",cbg,false);

//add the radio buttons to the frame
add(y);
add(n);

//add ItemListener to the radio buttons
y.addItemListener(this);
n.addItemListener(this);

}//end of constructor

//this method is called when radio button is clicked
public void itemStateChanged(ItemEvent ie)
{
repaint(); //call paint() method
}

//display the selected radio label
public void paint(Graphics g)
{

msg="Current Selection: ";
msg+=cbg.getSelectedCheckbox().getLabel();
g.drawString(msg,10,100);
}

public static void main(String args[])
{
//create the frame
Myradio mr=new Myradio();
mr.setSize(400,400);
mr.setTitle("My RadioButtons");
mr.setVisible(true);
//close the frame
mr.addWindowListener(new WindowAdapter()
{
public void windowClosing(WindowEvent we)
{
System.exit(0);
}
});
}
}

