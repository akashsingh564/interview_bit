class Outer {
static int y=10;
int k=220;
static class Inner{

void ma(){
System.out.println("dfgsdfds"+y+k);
}
}
public static void main(String ...a){
Outer.Inner i= new Inner();i.ma();
}
}


