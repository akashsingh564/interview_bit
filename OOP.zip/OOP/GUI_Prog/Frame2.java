import java.awt.*;
import java.awt.event.*;
class EmpFrame extends Frame implements ActionListener{
Button b1;
Label l1,l2,l3;
TextField t1,t2,t3;
int eid,esal;
String ename;
EmpFrame(int eid,String ename,int esal)
{
this.eid=eid;
this.ename=ename;
this.esal=esal;
//do not set any layout
this.setLayout(new FlowLayout());
l1=new Label("Employee id");
t1=new TextField(25);
l2=new Label("Employee name");
t2=new TextField(25);
l3=new Label("Employee sal");
t3=new TextField(25);
t1.setText(eid+"");
t2.setText(ename);
t3.setText(esal+"");
//create push buttons
b1=new Button("back");
//add the buttons to the frame
this.add(l1);
this.add(t1);
this.add(l2);
this.add(t2);
this.add(l3);
this.add(t3);

this.add(b1);
//add ActionListener to the buttons
b1.addActionListener(this);
}
//this button is called when a button is clicked
public void actionPerformed(ActionEvent ae)
{
dispose();
}
}