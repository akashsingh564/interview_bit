class trial
{
  public static void main(String args[])
{
System.out.print("ok");
new12 a = new new12();

a.new1();
}
}

class new12
{
	public void new1()
	{
		System.out.println("jafer");
	}
}
