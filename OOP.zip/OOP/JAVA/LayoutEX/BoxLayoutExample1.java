import java.awt.*;
import javax.swing.*;

public class BoxLayoutExample1 extends JFrame {
 public BoxLayoutExample1 () {
    Container c=getContentPane();
c.setLayout (new BoxLayout (c, BoxLayout.Y_AXIS));
     JButton b1= new JButton("1");
   JButton b2= new JButton("2");
JButton b3= new JButton("3");
c.add(b1);c.add(b2);c.add(b3);
    }
public static void main(String args[]){
BoxLayoutExample1 b=new BoxLayoutExample1();
b.setSize(400,400);
b.setVisible(true);
}
}