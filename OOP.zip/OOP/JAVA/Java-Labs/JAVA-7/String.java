class String
{
public static void main(String []args)
{
	StringBuffer s1=new StringBuffer("hello");
	StringBuffer s2=new StringBuffer("hello");
	String s11=s1.toString();
	String s12=s2.toString();
	System.out.println("check="+(s11.equals(s12)));
}
}
