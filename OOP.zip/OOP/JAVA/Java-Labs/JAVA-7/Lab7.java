abstract class Bank
{
	String bname;
	int bid,amount;
	void pfloan()
	{
		System.out.println("pfloan="+(amount*12/100.0));
	}
	void vloan()
	{
		System.out.println("vloan="+(amount*10/100.0));
	}
	void mloan()
	{
		System.out.println("mloan="+(amount*5/100.0));
	}
	abstract void personalloan();
}

class SBH extends Bank
{
	SBH(String bname,int bid,int amount)
	{
	this.bname=bname;
	this.bid=bid;
	this.amount=amount;
	}
	void personalloan()
	{
		System.out.println("personal loan="+(amount*8/100.0));
	}
}


class AB extends Bank
{
	AB(String bname,int bid,int amount)
	{
	this.bname=bname;
	this.bid=bid;
	this.amount=amount;
	}
	void personalloan()
	{
		System.out.println("personal loan="+(amount*18/100.0));
	}
}

class Lab7
{
	public static void main(String []args)
	{
		if(args[0].equals("SBH"))
		{
			SBH s=new SBH("XY",123,50000);
			
		}
		else if(args[0].equals("AB"))
		{
			AB s=new AB("PS",156,25000);
		/**	a.pfloan();
			a.vloan();
			a.mloan();
			a.personalloan(); **/
		}
			s.pfloan();
			s.vloan();
			s.mloan();
			s.personalloan();

	}	



}
