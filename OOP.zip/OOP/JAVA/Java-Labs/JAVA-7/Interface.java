interface Bank
{
	int minbal=5000;
	void deposit(int amt);
	void withDraw(int amt);
	void finalBal();
}

class SBH implements Bank
{
	int balance;
	public void deposit(int amt)
	{
		System.out.println("deposit="+(balance+amt));
	}
	public void withDraw(int amt)
	{
		if((balance-amt)>minbal)
			System.out.println("deposit="+balance+amt);
		else
			System.out.println("Not possible");	
	}
	public void finalBal()
	{
		System.out.println("Final amount="+balance);
	}
}

class Interface
{
	public static void main(String args[])
	{
		SBH s1=new SBH();
		s1.balance=500000;
		if(args[0].equals("deposit"))
			s1.deposit(Integer.parseInt(args[1]));
		else if(args[0].equals("withDraw"))
			s1.withDraw(Integer.parseInt(args[1]));

		else if(args[0].equals("finalBal"))
			s1.finalBal();
	}
}
