class Emp
{
	String ename;
	int eid,esal;
	Emp(int eid,int esal,String ename)
	{
		this.eid=eid;
		this.esal=esal;
		this.ename=ename;
	}
	void display()
	{
		System.out.println("eid="+eid+"ename="+ename+"esal="+esal);
	}
	public boolean equals(Object o2)
	{
		Emp e11=(Emp)o2;
		if((this.eid==eid)&&(this.ename==ename)&&(this.esal==esal))
			return true;
		else
			return false;
	}

	public static void main(String []args)
	{
		Emp e1=new Emp(123,5000,"XY");
		Emp e2=new Emp(123,5000,"XY");
		e1.display();
		e2.display();
		System.out.println("check="+(e1.equals(e2)));
	}
}
