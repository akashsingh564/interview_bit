//starts with i
class File3{
	public static void main(String []arg){
		for(int i=0;i<arg.length;i++)
		{
			if(arg[i].startsWith("i") {
					System.out.println(arg[i]);}
		}
	}
}
