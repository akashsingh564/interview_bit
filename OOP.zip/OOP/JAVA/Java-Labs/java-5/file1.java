class file1{
void m1(int ...a)
{
System.out.println("HI");
}
public static void main(String []args)
{
File1 x=new File1();
x.m1();
x.m1(1,2,3);

}
