import java.util.*;
class File10{
	public static void main(String []args)
	{
		int a=10;
		Integer i=new Integer(a);
		Integer k=new Integer(12);
		System.out.println("i val "+i.intValue()+"k value"+k.intValue());
	}
}
