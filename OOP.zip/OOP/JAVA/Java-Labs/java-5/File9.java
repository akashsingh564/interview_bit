//static blocks executes before main , if present!!
import java.util.*;
class File9{
	static
	{
		System.out.println("k");
	}
	public static void main(String ...a){
		System.out.println("S");
	}
	static
	{
		System.out.println("p");
	}
}
