class File5{
	public static void main(String []arg){
		for(int i=0;i<arg.length;i++)
		{
			char k[]=arg[i].toCharArray();
			if(k[0]=='i') {
					System.out.println(arg[i]);}
		}
	}
}
