//string into separate words
//two arguments
import java.util.*;
class File8{
	public static void main(String arg[])
	{
		StringTokenizer st=new StringTokenizer(arg[0],"*");
		System.out.println(st.countTokens());
		while(st.hasMoreTokens())
			System.out.println(st.nextToken());

	}
}
