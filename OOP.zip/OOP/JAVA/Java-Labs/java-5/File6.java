//ends with s
class File6{
	public static void main(String []arg){
		for(int i=0;i<arg.length;i++)
		{
			if(arg[i].endsWith("s")){
					System.out.println(arg[i]);}
		}
	}
}
