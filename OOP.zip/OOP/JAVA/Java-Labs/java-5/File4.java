class File4{
	public static void main(String []arg){
		for(int i=0;i<arg.length;i++)
		{
			if(arg[i].charAt(0)=='i') {
					System.out.println(arg[i]);}
		}
	}
}
