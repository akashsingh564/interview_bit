import java.util.*;
class File11{
	public static void main(String []args)
	{
		char a=10;
		Character i=new Character('a');
		Integer k=new Integer(12);
		System.out.println("i val "+i.charValue()+"k value"+k.intValue());
	}
}
