class File2{
	public static void main(String []arg){
		for(int i=0;i<arg.length;i++)
		{
			if(arg[i].length()==2){
					System.out.println(arg[i]);}
		}
	}
}
