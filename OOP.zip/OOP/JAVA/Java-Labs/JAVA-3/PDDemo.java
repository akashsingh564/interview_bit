package p2;
import p1.*;
class PDDemo extends DDemo{
public static void main(String []args){
PDDemo pd=new PDDemo();
System.out.println(pd.a);
}
}
