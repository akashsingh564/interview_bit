class PDemo{

private int a=5;
/*public static void main(String []args){

PDemo a1=new PDemo();
System.out.println(a1.a);
}*/
}

class Demo{
public static void main(String []args)
{

PDemo a1=new PDemo();
System.out.println(a1.a);
}

}
