class Student{
int sid;
String sname;
int smarks;
String sbranch;
String sgrade;

void calcGrade()
{
sgrade=(smarks>50)?"A":"B";
}
Void dispEmpDetails()
{
System.out.println("sid= "+sid+"\nsname= "+sname+"\nsmarks= "+smarks+"\nsbranch= "+sbranch+"\nsgrade= "+sgrade);
}

public static void main(String []args){
Student s1=new Student();
s1.sid=1;
s1.sname="Raju";
s1.smarks=56;
s1.sbranch="Computer Science";
s1.calcGrade();
s1.dispEmpDetails();

Student s2=new Student();
s2.sid=2;
s2.sname="Rani";
s2.smarks=44;
s2.sbranch="Information Systems";
s2.calcGrade();
s2.dispEmpDetails();
}

}
