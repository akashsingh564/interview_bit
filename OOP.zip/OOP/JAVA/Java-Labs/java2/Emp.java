class Emp{
int eid;
String ename;
double ebasic;
double eda;
double epf;
double egross;
double etax;
double eded;
double enet;

void calcDed(){
eda=ebasic*(80/100.0);
egross=ebasic+eda;
epf=egross*(12/100.0);
etax=egross*(10/100.0);
eded=epf+etax;
}
void calNetSal(){
enet=egross-eded;
}
void dispEmpDetails(){
System.out.println("eid= "+eid+"\nename= "+ename+"\neda= "+eda+"\negross= "+egross);
}

public static void main(String []args)
{
Emp e=new Emp();
e.eid=1;
e.ename="Sam";
e.ebasic=60000.0;
e.calcDed();
e.calNetSal();
e.dispEmpDetails();




}

}
