class Raj{
short s1;
int i;
double d;
String s;
public static void main(String []args){
Raj d1=new Raj();
System.out.println("int i= "+d1.i+"\nshort s1= "+d1.s1+"\ndouble d= "+d1.d+"\nString s= "+d1.s);


}
}
