class Demo1{
public static void main(String []args)
{
String s1="Good";
String s2="Good";
System.out.println("check "+s1==s2);            //System.out.println("check "+(s1==s2));
                                                //Here bracket plays an imp role ,because conconation occurs of mini bracet is no there.
System.out.println("check1 "+s1.equals(s2) );


}





}
