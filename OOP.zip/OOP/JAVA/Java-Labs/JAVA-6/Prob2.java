class Bank
{
	int id;
	String name;
	String location;
	int amount;
	double loan;
	void pfLoan()
	{
		loan=amount*10/100.0;	//interest is 10 percent	
	}
	void display()
	{
		System.out.println("id="+id+"name="+name+"location="+location+"amount="+amount+"loan="+loan);
	}
}
class AB extends Bank
{
	double vloan;
	AB(int i,String na,int a,String loc)
	{
		id=i;	
		name=na;
		amount=a;
		loc=location;
	}
	void vLoan()
	{
		vloan=amount*5/100.0;
	}
	void vDisplay()
	{
		display();
		System.out.println("vloan="+vloan);
	}
}
class SBH extends Bank
{
	double ploan;
	SBH(int i,String na,int a,String loc)
	{

		id=i;	
		name=na;
		amount=a;
		loc=location;
	}
	void pLoan()
	{
		ploan=amount*2/100.0;
	}
	void pDisplay()
	{
		display();
		System.out.println("ploan="+ploan);
	}

}
class Prob2
{
	public static void main(String args[])
	{
		if(args[0].equals("AB"))
		{
			AB e1=new AB(1,"Phani",5000,"Hyd");
			e1.pfLoan();
			e1.vLoan();
			e1.vDisplay();
		}
		else if(args[0].equals("SBH"))
		{
			SBH s1=new SBH(2,"Naidu",5000,"Sec");
			s1.pfLoan();			
			s1.pDisplay();
		}


	}



}
