class Person{

	int id,age;
	String name;
	void display()
	{
		System.out.println("id="+id+"age="+age+"name="+name);
	}
}
class Employee extends Person
{
	int esal;
	double etax,enet;
	Employee(int i,int a,String na,int s)
	{
		id=i;
		age=a;
		name=na;
		esal=s;
	}
	void calDisplay()
	{
		display();
		etax=esal*10/100.0;
		enet=esal-etax;
		System.out.println("enet="+enet);
	}
}
class Student extends Person
{
	String sbranch,grade;
	double cgpa;
	Student(int i,int a,String na,String bn,double cg)
	{
		id=i;
		age=a;
		name=na;
		sbranch=bn;
		cgpa=cg;
	}
	void calSDisplay()
	{
		display();
		if((cgpa>=9.0)&&(cgpa<=10.0))
			grade="excellent";
		else
			grade="average";
		System.out.println("grade="+grade+"sbranch="+sbranch);
	}
}
class Lab6
{
	public static void main(String args[])
	{
		if(args[0].equals("Employee"))
		{
			Employee e1=new Employee(123,30,"Phani",5000);
			e1.calDisplay();
		}
		else if(args[0].equals("Student"))
		{
			Student s1=new Student(456,20,"Naidu","Information systems",8);
			s1.calSDisplay();
		}

	}
}





