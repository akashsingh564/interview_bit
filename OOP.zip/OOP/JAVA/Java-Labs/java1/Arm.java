class Arm{

public static void main(String []args)
{
int sum=0;
int n=153;
int d=n;
int r;
while(n>0)
{
r=n%10;
sum=sum+r*r*r;
n=n/10;
}
if(sum==d)
{
System.out.println("Number is Armstrong");
}
else
{
System.out.println("Number is Not Armstrong");
}
}
}
