class Fact{

public static void main(String []args)
{
int n=5;
int fact=n;
for(;n>0;n--)
{
fact=fact*n;
}
System.out.println(fact);
}

}
