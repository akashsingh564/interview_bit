class Xyz
{
public static void main(String []args)

{
System.out.println("hi "+ "hello" +2+3);
}

}
