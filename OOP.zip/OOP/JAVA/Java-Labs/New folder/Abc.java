class Abc
{
public static void main(String []args)

{

int a=1;
int b=2;
System.out.println("sum is  "+ (a+b));
System.out.println("subtraction is "+ (a-b));
}

}
