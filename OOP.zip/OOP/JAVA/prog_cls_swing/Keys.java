//catching which key is pressed
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class Keys extends JFrame implements KeyListener
{
//vars
JTextArea ta;
String msg="";

Keys()
{
Container c=getContentPane();
//create textarea
ta=new JTextArea(5,25);

//add the text area to the frame
c.add(ta);


//add Key listener to the text area
ta.addKeyListener(this);
}//end of constructor

 
public void keyPressed(KeyEvent ke)
{
int keycode=ke.getKeyCode();
 msg+="\nKey Code:"+keycode;
String keyname=ke.getKeyText(keycode);
 msg+="\nKey pressed:"+keyname;
  ta.setText(msg);
  msg="";
}
public void keyTyped(KeyEvent ke)
{

}
public void keyReleased(KeyEvent ke)
{
int keycode=ke.getKeyCode();
 msg+="\nKey Code:"+keycode;
String keyname=ke.getKeyText(keycode);
 msg+="\nKey pressed:"+keyname;
  ta.setText(msg);
  msg="";
}


public static void main(String args[])
{
//create the frame
Keys k=new Keys();
k.setSize(400,400);
k.setTitle("Catch the key");
k.setVisible(true);
k.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}

