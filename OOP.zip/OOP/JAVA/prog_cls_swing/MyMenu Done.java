import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class MyMenu extends JFrame implements ActionListener {
JMenuBar mb;
JMenu file,font;
JMenuItem op,sa,cl,cp,pt,f1,f2;
MyMenu(){
Container c= getContentPane();
c.setLayout(new BorderLayout());
mb=new JMenuBar();
c.add("North",mb);
file= new JMenu("File");
mb.add(file);
op= new JMenuItem("Open");
sa= new JMenuItem("save");
cl= new JMenuItem("close");
cp= new JMenuItem("copy");
pt= new JMenuItem("print");
font=new JMenu("Font");
file.add(op);
file.add(sa);
file.add(cp);
file.add(pt);
file.addSeparator();
file.add(cl);
file.add(font);
f1= new JMenuItem("Arial");
f2= new JMenuItem("Times New Roman");
font.add(f1);
font.add(f2);
op.addActionListener(this);
sa.addActionListener(this);
cl.addActionListener(this);
cp.addActionListener(this);
pt.addActionListener(this);
font.addActionListener(this);
f1.addActionListener(this);
f2.addActionListener(this);
}
public void actionPerformed(ActionEvent ae){
//if(op.isArmed())
//System.out.println("Open is Clciked");
//if(sa.isArmed())
//System.out.println("Save is Clciked");
//if(cl.isArmed())
//System.out.println("close is Clciked");
//if(cp.isArmed())
//System.out.println("copy is Clciked");
//if(pt.isArmed())
//System.out.println("print is Clciked");
//if(f1.isArmed())
//System.out.println("Arial is Clciked");
//if(f2.isArmed())
//System.out.println("Times New Roman is Clciked");
	
JMenuItem s = (JMenuItem)(ae.getSource());
String sc = s.getLabel();
System.out.println(sc + " is clicked");
}

public static void main(String ...arg){
MyMenu  m= new MyMenu();
m.setSize(300,400);
m.setVisible(true);
m.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}