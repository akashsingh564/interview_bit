// display text in a frame
import javax.swing.*;
import java.awt.*;
class MyPanel  extends  JPanel
{
MyPanel()
{
this.setBackground(Color.green);
}
//override
public void paintComponent(Graphics g)
{
super.paintComponent(g);
g.setColor(Color.red);
g.setFont(new Font("Helvetica",Font.BOLD,34));
g.drawString("Hello ",50,100);
}
}

class Frame4 extends JFrame
{
Frame4()
{
Container c=this.getContentPane();
MyPanel mp= new MyPanel();
c.add(mp);
}
public static void main(String []args)
{
Frame4 jf= new Frame4();
jf.setTitle("Display text");
jf.setSize(200,200);
jf.setVisible(true);
// close the application  upon clicking on close button of  frame
jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}