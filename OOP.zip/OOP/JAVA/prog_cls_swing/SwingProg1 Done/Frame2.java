import javax.swing.*;
class Frame2
{
public static void main(String []args)
{
JFrame jf= new JFrame("First Frame");
jf.setSize(200,200);
jf.setVisible(true);
// close the application  upon clicking on close button of  frame
jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}