import javax.swing.*;
import java.awt.*;
class Frame3
{
public static void main(String []args)
{
JFrame jf= new JFrame("First Frame");
Container c=jf.getContentPane();
c.setBackground(Color.green);
jf.setSize(200,200);
jf.setVisible(true);
// close the application  upon clicking on close button of  frame
jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}