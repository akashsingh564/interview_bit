import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class Frame9 extends JFrame implements ActionListener
{
JCheckBox cb1,cb2;
JRadioButton rb1,rb2;
JTextArea ta;
ButtonGroup bg;
String msg="";
Container c;
Frame9()
{
c=getContentPane();
c.setLayout(new FlowLayout());
ta=new JTextArea(10,20);
cb1=new JCheckBox("java",true);
cb2=new JCheckBox("SQL");
rb1=new JRadioButton("Male");
rb2=new JRadioButton("Female", true);
bg=new ButtonGroup();
bg.add(rb1);
bg.add(rb2);
c.add(cb1);
c.add(cb2);
c.add(rb1);
c.add(rb2);
c.add(ta);
cb1.addActionListener(this);
cb2.addActionListener(this);
rb1.addActionListener(this);
rb2.addActionListener(this);
}
public void  actionPerformed(ActionEvent ae)
{
if(cb1.getModel().isSelected()) msg+="\nJava";
if(cb2.getModel().isSelected()) msg+="\nSQL";
if(rb1.getModel().isSelected()) msg+="\nMale";
else msg+="\n Female";
ta.setText(msg);
//reset the msg to empty string
msg="";
}
public static void main(String []args)
{
Frame9 jf= new Frame9();
jf.setTitle("Check Boxes and radio buttons");
jf.setSize(500,400);
jf.setVisible(true);
// close the application  upon clicking on close button of  frame
jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}