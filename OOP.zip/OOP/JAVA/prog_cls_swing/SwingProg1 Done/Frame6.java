import javax.swing.*;
import java.awt.*;
class Frame6 extends JFrame
{
JButton b1,b2,b3;
Frame6()
{
Container c=this.getContentPane();
c.setLayout(new FlowLayout());
b1=new JButton("Submit");
b2=new JButton("Cancel");
c.add(b1);
c.add(b2);
}
public static void main(String []args)
{
Frame6 jf= new Frame6();
jf.setTitle("Display text");
jf.setSize(200,200);
jf.setVisible(true);
// close the application  upon clicking on close button of  frame
jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}