import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class Frame8 extends JFrame implements ActionListener
{
JButton b1;
Container c;
Frame8()
{
c=this.getContentPane();
c.setLayout(new FlowLayout());
ImageIcon  i= new ImageIcon("images.gif");
JLabel j=new JLabel("Button");
b1=new JButton("Submit",i);
b1.setBackground(Color.yellow);
b1.setForeground(Color.red);
b1.setFont(new Font("Arial",Font.BOLD,20));
b1.setToolTipText("This is button");
b1.setMnemonic('s');
b1.addActionListener(this);
c.add(b1);
c.add(j);
}
public void  actionPerformed(ActionEvent ae)
{
c.setBackground(Color.green);
}
public static void main(String []args)
{
Frame8 jf= new Frame8();
jf.setTitle("Display text");
jf.setSize(500,400);
jf.setVisible(true);
// close the application  upon clicking on close button of  frame
jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}