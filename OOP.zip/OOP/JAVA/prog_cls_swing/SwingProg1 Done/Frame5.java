// display text in a frame
import javax.swing.*;
import java.awt.*;
class Frame5 extends JFrame
{
JLabel lbl;
Frame5()
{
Container c=this.getContentPane();
c.setLayout(new FlowLayout());
c.setBackground(Color.green);
lbl=new JLabel("helllo");
lbl.setFont(new Font("Helvetica",Font.BOLD,34));
lbl.setForeground(Color.red);
c.add(lbl);
}
public static void main(String []args)
{
Frame5 jf= new Frame5();
jf.setTitle("Display text using Label");
jf.setSize(200,200);
jf.setVisible(true);
// close the application  upon clicking on close button of  frame
jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}