import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class MyMouse  extends JFrame implements MouseListener
{
//vars
JTextArea ta;
MyMouse()
{
Container c=getContentPane();
c.setLayout(new FlowLayout());
ta=new JTextArea("hfsdhds",5,20); 
c.add(ta);
//add mouse listener to the text area
ta.addMouseListener(this);
}//end of constructor

 public void mouseClicked(MouseEvent me)
{
System.out.println("Mouse Clicked(pressing and relaeasing)");
}
public void mouseEntered(MouseEvent me)
{
System.out.println("called on Mouse over ");
}
public void mouseExited(MouseEvent me)
{
System.out.println("called on Mouse exit ");
}
public void mousePressed(MouseEvent me)
{
System.out.println("Mouse pressed(only pressed)");
}
public void mouseReleased(MouseEvent me)
{
System.out.println("Mouse Released(only released)");
}


public static void main(String args[])
{
//create the frame
MyMouse k=new MyMouse();
k.setSize(400,400);
k.setTitle("Catch the key");
k.setVisible(true);
k.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}

