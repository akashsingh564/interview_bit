//scroll bar demo
import java.awt.*;
import java.awt.event.*;
class Myscroll extends Frame implements AdjustmentListener
{
//vars
String msg="";
Scrollbar s1;

Myscroll()
{
//set flow layout manager
this.setLayout(new FlowLayout());
//create vertical scroll bar
s1=new Scrollbar(Scrollbar.VERTICAL,0,1000,0,1000);

//add the scroll  bar to the frame
add(s1);


//add adjustment listener to the scrollbar
s1.addAdjustmentListener(this);
}//end of constructor

//this method is called when scroll bar adjusted 
public void adjustmentValueChanged(AdjustmentEvent ae)
{
repaint(); //call paint() method
}

public void paint(Graphics g)
{
g.drawString("SCROLLBAR POSITION",20,150);
msg+=s1.getValue();
g.drawString(msg,20,180);
msg="";
}

public static void main(String args[])
{
//create the frame
Myscroll ms=new Myscroll();
ms.setSize(400,400);
ms.setTitle("My Scrollbar");
ms.setVisible(true);

//set flow layout manager
ms.setLayout(new FlowLayout());



//close the frame
ms.addWindowListener(new WindowAdapter()
{
public void windowClosing(WindowEvent we)
{
System.exit(0);
}
});
}
}

